var path = require("path")
//HTML打包
var htmlWebpackPlugin = require("html-webpack-plugin")
//文件拷贝
var CopyWebpackPlugin = require("copy-webpack-plugin")
var webpack = require("webpack")
var config = require("./config")
//CSS提取
const ExtractTextPlugin = require("extract-text-webpack-plugin")
//CSS压缩
const OptimizeCSSPlugin = require("optimize-css-assets-webpack-plugin")
module.exports = {
    //入口文件
    entry : config.base.entry,
    output: {
        //打包路径
        path : config.base.outputPath,
        filename: "js/"+config.base.outputFileName,
        //组件懒加载
        chunkFilename: "[id]-[name]-[hash].js"
    },
    module: {
        rules: [
            {
                test: /\.js|.jsx$/,
                use: [{
                    loader: "babel-loader",
                    options: config.babel
                }]
            },
            {
                test: /\.css/,
                use: ExtractTextPlugin.extract({
                    fallback: "style-loader",
                    use: "css-loader"
                })
            },
            {
                test: /\.(jpg|png|gif|ttf|woff|eot|svg)$/,
                use: ["url-loader"]
            },
            {
                test: /\.html$/,
                use: ["html-loader"]
            }
        ]
    },
    resolve: {
        extensions : [".js",".vue"]
    },
    plugins: [
        new htmlWebpackPlugin({
            filename: "index.html",
            template: config.base.templatePath,
            minify: config.base.htmlMinify
        }),
        new CopyWebpackPlugin([
            {
                from: path.resolve(_dirname,"../src/static"),
                to: config.base.outputPath+"/static",
                ignore: [".*"]
            }
        ]),
        new ExtractTextPlugin({
            filename: "css/[name].[contenthash].css",
            allChunks: true
        })
    ]
}
