import React,{ Component } from 'react'
/**
 * 采用用ES6的写法
 **/
class App extends Component {
    /**
     * 相关数据的操作
     * 数据的请求、当前数据的检测
     * @param {*} props 
     */
    constructor(props) {
        super(props)
        this.state = {
            num: "www.baidu.com"
        }
        this.onClickChange = this.onClickChange.bind(this)
        console.log("One constructor");
       
    }
    componentWillMount() {
        console.log("Two componentWillMount");
    }
    /**
     * dom编译完成，并且渲染到真实的dom中
     * 可以做dom的处理
     * 可以做具体的事件监听
     * 某些插件的实例化
     */
    componentDidMount() {
        console.log("Four componentDidMount");
    }
    componentWillReceiveProps(props) {
        console.log("props");
    }
    onClickChange(){
        console.log("onClickChange");
        this.setState({
            num:"www.google.com"
        },()=>{
            console.log("值:"+this.state.num);
        })
       
    }
    /**
     * 纯函数
     * 不能调用setstate进行数据改变
     * 不能做数据的产生和保存
     * 返回数据的dom拼接号的JSX
     */
    render() {
        console.log("Three render");
        return (
            <div>
                <h1>生命周期</h1>
                <button onClick = { this.onClickChange }>确认</button>
            <h1>{ this.state.num }</h1>
            </div>
            
        )
    }
}

export default App